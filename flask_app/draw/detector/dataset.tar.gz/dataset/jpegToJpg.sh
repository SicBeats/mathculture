for f in ./JPEGImages/*.jpeg; do mv -- "$f" "${f%.jpeg}.jpg"; done
